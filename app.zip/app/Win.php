<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Win extends Model
{
    //
}
