﻿@extends('layouts.app')

@section('content')

  <!-- inner-hero-section start -->
  <section class="inner-hero-section bg_img" data-background="assets/images/bg-img/inner-hero.jpg">
    <div class="container">
      <div class="row">
        <div class="col-lg-12" style="text-align: center;">
          <img src="images/picture.jpg">
          <h2 class="page-title">{{$user['name']}}</h2>
          <div  style="padding-top: 60px;">
            <button class="btn btn-success">Update Profile <span class="glyphicon glyphicon-star"></span></button>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- inner-hero-section end -->

    <!-- faq-section start -->
  <div class="faq-section pt-120 pb-120 section-bg-two">
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-lg-10">
          <div class="faq-area">
            <ul class="nav justify-content-center" id="pills-tab" role="tablist">
              <li class="nav-item">
                <a class="nav-link active" id="general-tab" data-toggle="pill" href="#general" role="tab" aria-controls="general" aria-selected="true">Personal</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" id="about-tab" data-toggle="pill" href="#about" role="tab" aria-controls="about" aria-selected="false">Address</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" id="ticket-tab" data-toggle="pill" href="#ticket" role="tab" aria-controls="ticket" aria-selected="false">Billings</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" id="wining-tab" data-toggle="pill" href="#wining" role="tab" aria-controls="wining" aria-selected="false">Wining</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" id="result-tab" data-toggle="pill" href="#result" role="tab" aria-controls="result" aria-selected="false">Results</a>
              </li>
            </ul>
            <div class="tab-content" id="pills-tabContent">
              <div class="tab-pane fade show active" id="general" role="tabpanel" aria-labelledby="general-tab">
                <div class="faq-item">
                  <h4 class="title">Update personal details</h4>
                
                  <form class="contact-form" method="post" action="{{url('/account/update')}}">
                    @csrf
                    <div class="form-row">
                      <div class="form-group col-lg-6">
                        <input type="text" name="contact-name" value="{{$user['name']}}" id="contact-name" placeholder="Full name">
                      </div>
                      <div class="form-group col-lg-6">
                        <input type="email" name="contact-email" value="{{$user['email']}}" id="contact-email" placeholder="Email address">
                      </div>
                      <div class="form-group col-lg-6">
                        <input type="tel" name="contact-phone" id="contact-phone" placeholder="password">
                      </div>
                      <div class="form-group col-lg-6">
                        <input type="text" name="contact-subject" id="contact-subject" placeholder="confirm password">
                      </div>
                      <div class="col-lg-12">
                        <input name="file" type="file" placeholder="Upload avatar"/>
                      </div>
                      <div class="col-lg-12">
                        <button type="submit" class="cmn-btn">Update</button>
                      </div>
                    </div>
                  </form>
                  
                </div><!-- faq-item end -->
              </div>
              <div class="tab-pane fade" id="about" role="tabpanel" aria-labelledby="about-tab">
                <div class="faq-item">
                <h4 class="title">Update physical address</h4>
                  <form class="contact-form">
                    <div class="form-row">
                      <div class="form-group col-lg-6">
                        <input type="text" name="contact-name" id="contact-name" placeholder="Full name">
                      </div>
                      <div class="form-group col-lg-6">
                        <input type="email" name="contact-email" id="contact-email" placeholder="Last name">
                      </div>
                      <div class="form-group col-lg-6">
                        <input type="tel" name="contact-phone" id="contact-phone" placeholder="Phone Number">
                      </div>
                      <div class="form-group col-lg-6">
                        <input type="text" name="contact-subject" id="contact-subject" placeholder="Company Name">
                      </div>
                      <div class="form-group col-lg-6">
                        <input type="text" name="contact-name" id="contact-name" placeholder="Country">
                      </div>
                      <div class="form-group col-lg-6">
                        <input type="email" name="contact-email" id="contact-email" placeholder="Street Address ">
                      </div>
                      <div class="form-group col-lg-6">
                        <input type="tel" name="contact-phone" id="contact-phone" placeholder="City">
                      </div>
                      <div class="form-group col-lg-6">
                        <input type="text" name="contact-subject" id="contact-subject" placeholder="Post Code">
                      </div>
                      <div class="form-group col-lg-12">
                        <input type="text" name="contact-subject" id="contact-subject" placeholder="Attatch Location ">
                      </div>
                      <div class="col-lg-12">
                        <button type="submit" class="cmn-btn">Save</button>
                      </div>
                    </div>
                  </form>
                </div><!-- faq-item end -->
              </div>
              <div class="tab-pane fade" id="ticket" role="tabpanel" aria-labelledby="ticket-tab">
                <div class="faq-item">
                  <h4 class="title">Credit or Debit Card </h4>
                  <form class="contact-form">
                    <div class="form-row">
                      <div class="form-group col-lg-6">
                        <input type="text" name="name*" id="contact-name" placeholder="Name on Card*">
                      </div>
                      <div class="form-group col-lg-6">
                        <input type="email" name="number" id="contact-email" placeholder="Card Number*">
                      </div>
                      <div class="form-group col-lg-6">
                        <input type="text" name="expiry-m" id="contact-phone" placeholder="Expiry date* - Month">
                      </div>
                      <div class="form-group col-lg-6">
                        <input type="text" name="expiry-y" id="contact-subject" placeholder="Expiry date* - Year*">
                      </div>
                      <div class="form-group col-lg-12">
                        <input name="cvc-number" id="contact-message" placeholder="CVC number*">
                      </div>
                      <div class="col-lg-4">
                        <button type="submit" class="cmn-btn">Save</button>
                      </div>
                      <div class="col-lg-4">
                        <button type="submit" class="cmn-btn">Paypal</button>
                      </div>
                      <div class="col-lg-4">
                        <button type="submit" class="cmn-btn">Bitcoin</button>
                      </div>
                    </div>
                  </form>
                </div><!-- faq-item end -->
              </div>
              <div class="tab-pane fade" id="wining" role="tabpanel" aria-labelledby="wining-tab">
                <div class="faq-item">
                  <h4 class="title">Competition Details </h4>
                  <form class="contact-form">
                    <div class="form-row">
                      <div class="form-group col-lg-6">
                        <label id="contact-name">Product :</label> 
                      </div>
                      <div class="form-group col-lg-6">
                        <label id="contact-name">Fridge</label> 
                      </div>
                      <div class="form-group col-lg-6">
                        <label id="contact-name">Amount :</label> 
                      </div>
                      <div class="form-group col-lg-6">
                        <label id="contact-name">€85.63</label> 
                      </div>                      
                      <div class="form-group col-lg-6">
                        <label id="contact-name">Tickets :</label> 
                      </div>
                      <div class="form-group col-lg-6">
                        <label id="contact-name">5</label> 
                      </div>
                      <div class="form-group col-lg-6">
                        <label id="contact-name">Question : Maximum operating voltage for fridge</label> 
                      </div>
                      <div class="form-group col-lg-6">
                        <label id="contact-name">250V</label> 
                      </div>
                      <div class="col-lg-12">
                        <button type="submit" class="cmn-btn">Save</button>
                      </div>
                    </div>
                  </form>
                </div><!-- faq-item end -->
              </div>
              <div class="tab-pane fade" id="result" role="tabpanel" aria-labelledby="result-tab">
                <div class="faq-item">
                  <h4 class="title">Competition Results </h4>
                  <form class="contact-form">
                    <div class="form-row">
                      <div class="form-group col-lg-6">
                        <label id="contact-name">Product :</label> 
                      </div>
                      <div class="form-group col-lg-6">
                        <label id="contact-name">Fridge</label> 
                      </div>
                      <div class="form-group col-lg-6">
                        <label id="contact-name">Winners :</label> 
                      </div>
                      <div class="form-group col-lg-6">
                        <label id="contact-name">15</label> 
                      </div>
                      <div class="form-group col-lg-6">
                        <label id="contact-name">Question : Maximum operating voltage for fridge</label> 
                      </div>
                      <div class="form-group col-lg-6">
                        <label id="contact-name">250V</label> 
                      </div>
                      <div class="col-lg-12">
                        <button type="submit" class="cmn-btn">Save</button>
                      </div>
                    </div>
                  </form>
                </div><!-- faq-item end -->

              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- faq-section end -->

  
@endsection